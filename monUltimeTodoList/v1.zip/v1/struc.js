// Tableau de todoliste
let Listes = [
    //Todoliste 1
    { 
        name:"Titre de la to liste",
        tasks : [
            { text:"1kg Pommes", cross: true || false }
        ]
    },
    //Todoliste 2 
    { 
        name:"Titre de la to liste",
        tasks : [
            { text:"1kg Pommes", cross: true || false }
        ]
    },
    //Todoliste 3
    { 
        name:"Titre de la to liste",
        tasks : [
            { text:"1kg Pommes", cross: true || false }
        ]
    }
]